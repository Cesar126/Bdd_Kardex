# Sistema Empresarial

Sistema de gestión empresarial con funcionalidades de login, registro, gestión de empresas y productos.

## Requisitos

- PHP 7.4 o superior
- PostgreSQL 12 o superior
- Extensión PDO de PHP habilitada
- Extensión pgsql de PHP habilitada

## Instalación

1. Clonar el repositorio en tu servidor web:
```bash
git clone [URL_DEL_REPOSITORIO]
```

2. Crear la base de datos en PostgreSQL:
```sql
CREATE DATABASE sistema_empresarial;
```

3. Importar la estructura de la base de datos:
```bash
psql -U postgres -d sistema_empresarial -f database.sql
```

4. Configurar la conexión a la base de datos:
   - Editar el archivo `config/database.php`
   - Verificar que los datos de conexión sean correctos:
     - host: localhost
     - dbname: sistema_empresarial
     - username: postgres
     - password: 200520

5. Configurar los permisos de los archivos:
```bash
chmod 755 -R /ruta/al/proyecto
chmod 777 -R /ruta/al/proyecto/uploads
```

## Estructura del Proyecto

```
├── config/
│   └── database.php
├── database.sql
├── login.php
├── registro.php
├── empresas.php
├── productos.php
├── logout.php
└── README.md
```

## Funcionalidades

- Login de usuarios
- Registro de nuevos usuarios
- Gestión de empresas (crear, listar, editar, eliminar)
- Gestión de productos (crear, listar, editar, eliminar)
- Control de sesiones
- Interfaz responsiva con Bootstrap 5

## Seguridad

- Contraseñas hasheadas con password_hash()
- Protección contra SQL Injection usando PDO
- Validación de sesiones
- Sanitización de datos de entrada

## Soporte

Para reportar problemas o solicitar ayuda, por favor crear un issue en el repositorio.
