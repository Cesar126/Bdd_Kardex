-- Crear la base de datos
CREATE DATABASE sistema_empresarial;

-- Conectar a la base de datos
\c sistema_empresarial;

-- Tabla principal de empresas
CREATE TABLE tbl_empresa (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    razon_social VARCHAR(200) NOT NULL,
    estado VARCHAR(10) CHECK (estado IN ('activo', 'inactivo')) DEFAULT 'activo'
);

-- Usuarios para inicio de sesión
CREATE TABLE tbl_login (
    usuario VARCHAR(100) PRIMARY KEY,
    contrasena VARCHAR(255) NOT NULL,
    id_empresa INT,
    estado VARCHAR(10) CHECK (estado IN ('activo', 'inactivo')) DEFAULT 'activo',
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id)
);

-- Registro de usuarios con tipo de persona
CREATE TABLE tbl_registro (
    usuario VARCHAR(100) PRIMARY KEY,
    contrasena VARCHAR(255) NOT NULL,
    id_empresa INT,
    estado VARCHAR(10) CHECK (estado IN ('activo', 'inactivo')) DEFAULT 'activo',
    tipo_persona VARCHAR(10) CHECK (tipo_persona IN ('natural', 'juridica')) NOT NULL,
    tipo_usuario VARCHAR(10) CHECK (tipo_usuario IN ('estudiante', 'docente')) NOT NULL,
	estado_aprobacion VARCHAR(20) CHECK (estado_aprobacion IN ('pendiente', 'aprobado', 'rechazado')) DEFAULT 'pendiente',
	fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id)
);
--INSERT INTO tbl_registro (
--    usuario, contrasena, tipo_persona, tipo_usuario, estado, estado_aprobacion
--) VALUES (
--    'admin', 'admin', 'natural', 'docente', 'activo', 'aprobado'
--);
-- Relación entre empresas y usuarios
CREATE TABLE tbl_empresa_registro (
    id SERIAL PRIMARY KEY,
    id_empresa INT,
    usuario VARCHAR(100),
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id),
    FOREIGN KEY (usuario) REFERENCES tbl_registro(usuario)
);

-- Productos por empresa
CREATE TABLE tbl_producto (
    id SERIAL PRIMARY KEY,
    id_empresa INT,
    nombre VARCHAR(255) NOT NULL,
    descripcion TEXT,
    estado VARCHAR(20) CHECK (estado IN ('disponible', 'no disponible')) DEFAULT 'disponible',
    stock_actual INT DEFAULT 0,
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id)
);

-- Movimiento de inventario tipo kardex (relacionado con producto)
DROP TABLE IF EXISTS tbl_kardex;
CREATE TABLE tbl_kardex (
    kar_id SERIAL PRIMARY KEY,
    kar_fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    kar_tipo_movimiento VARCHAR(10) CHECK (kar_tipo_movimiento IN ('entrada', 'salida')) NOT NULL,
    kar_detalle TEXT,
    kar_entCantidad INT,
    kar_entValorUnitario DECIMAL(10,2),
    kar_entiValorTotal DECIMAL(12,2),
    kar_saldoCantidad INT,
    kar_saldoValorUnitario DECIMAL(10,2),
    kar_saldoValorTotal DECIMAL(12,2),
    kar_exisCantidad INT,
    kar_exisValorUnitario DECIMAL(10,2),
    kar_exisValorTotal DECIMAL(12,2),
    usu_id VARCHAR(100),
    emp_id INT,
    prod_id INT NOT NULL,
    kar_estado VARCHAR(20) CHECK (kar_estado IN ('activo', 'inactivo')) DEFAULT 'activo',
    FOREIGN KEY (usu_id) REFERENCES tbl_registro(usuario),
    FOREIGN KEY (emp_id) REFERENCES tbl_empresa(id),
    FOREIGN KEY (prod_id) REFERENCES tbl_producto(id)
);

-- Formularios de costo cero
CREATE TABLE tbl_CZF (
    id SERIAL PRIMARY KEY,
    id_empresa INT,
    descripcion TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id)
);

-- Encabezados de costos
CREATE TABLE tbl_HCosto (
    id SERIAL PRIMARY KEY,
    id_empresa INT,
    descripcion TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id)
);

-- Información de empleados
CREATE TABLE tbl_empleado (
    id SERIAL PRIMARY KEY,
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    cedula VARCHAR(20) UNIQUE,
    id_empresa INT,
    fecha_ingreso DATE,
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id)
);

-- Nómina (rol de pagos)
CREATE TABLE tbl_rol_de_pagos (
    id SERIAL PRIMARY KEY,
    id_empleado INT,
    fecha_pago DATE,
    total_pago DECIMAL(12,2),
    FOREIGN KEY (id_empleado) REFERENCES tbl_empleado(id)
);

-- Tarjeta de tiempo (asistencia)
CREATE TABLE tbl_tarjeta_de_tiempo (
    id SERIAL PRIMARY KEY,
    id_empleado INT,
    fecha DATE,
    hora_entrada TIME,
    hora_salida TIME,
    horas_trabajadas DECIMAL(5,2),
    FOREIGN KEY (id_empleado) REFERENCES tbl_empleado(id)
);

-- Catálogo de impuestos
CREATE TABLE tbl_impuestos (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100),
    porcentaje DECIMAL(5,2) NOT NULL
);

-- Costos de mano de obra
CREATE TABLE tbl_mano_de_obra (
    id SERIAL PRIMARY KEY,
    id_empresa INT,
    tipo VARCHAR(20) CHECK (tipo IN ('directa', 'indirecta')) NOT NULL,
    valor_hora DECIMAL(10,2),
    FOREIGN KEY (id_empresa) REFERENCES tbl_empresa(id)
); 

