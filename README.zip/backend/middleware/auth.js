const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  try {
    // Verificar si el header Authorization existe
    const authHeader = req.header('Authorization');
    
    if (!authHeader) {
      return res.status(401).json({ message: 'No hay token, autorización denegada' });
    }

    // Obtener el token del header y verificar que esté bien formateado
    const token = authHeader.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ message: 'Token no proporcionado correctamente, autorización denegada' });
    }

    // Verificar el token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Agregar el usuario al request
    req.user = decoded;
    
    next();
  } catch (error) {
    console.error('Error al verificar el token:', error);
    res.status(401).json({ message: 'Token no válido' });
  }
};
