const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const auth = require('../middleware/auth');

// Registro de usuario
router.post('/register', async (req, res) => {
  try {
    const { usuario, contrasena, tipo_persona, tipo_usuario } = req.body;

    // Validar que todos los campos estén presentes
    if (!usuario || !contrasena || !tipo_persona || !tipo_usuario) {
      return res.status(400).json({ message: 'Faltan datos en la solicitud' });
    }

    // Verificar si el usuario ya existe
    const userExists = await db.query(
      'SELECT * FROM tbl_registro WHERE usuario = $1',
      [usuario]
    );

    if (userExists.rows.length > 0) {
      return res.status(400).json({ message: 'El usuario ya existe' });
    }

    // Encriptar contraseña
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(contrasena, salt);
    // Determinar estado_aprobacion según el tipo de usuario
    let estado_aprobacion;

    if (tipo_usuario === 'docente') {
      estado_aprobacion = 'aprobado';
    } else if (tipo_usuario === 'estudiante') {
      estado_aprobacion = 'pendiente';
    } else {
      return res.status(400).json({ message: 'Tipo de usuario no válido' });
    }

    // Crear usuario en tbl_registro
    const result = await db.query(
      'INSERT INTO tbl_registro  (usuario, contrasena, tipo_persona, tipo_usuario, estado_aprobacion) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [usuario, hashedPassword, tipo_persona, tipo_usuario, estado_aprobacion]
    );

    res.status(201).json({
      message: 'Usuario registrado exitosamente',
      user: {
        usuario: result.rows[0].usuario,
        tipo_persona: result.rows[0].tipo_persona,
        tipo_usuario: result.rows[0].tipo_usuario,
        estado_aprobacion
      }
    });
  } catch (error) {
    console.error(error);  // Aquí se pueden ver detalles del error
    res.status(500).json({ message: 'Error en el servidor' });
  }
});


// Login
router.post('/login', async (req, res) => {
  try {
    const { usuario, contrasena } = req.body;

    // Validar que los datos de login estén presentes
    if (!usuario || !contrasena) {
      return res.status(400).json({ message: 'Faltan datos en la solicitud' });
    }

    // Verificar si el usuario existe
    const result = await db.query(
      'SELECT * FROM tbl_registro WHERE usuario = $1',
      [usuario]
    );

    if (result.rows.length === 0) {
      return res.status(400).json({ message: 'Credenciales inválidas' });
    }

    const user = result.rows[0];

    // Verificar si el estudiante está aprobado
    if (user.tipo_usuario === 'estudiante' && user.estado_aprobacion !== 'aprobado') {
      return res.status(403).json({
        message: 'Tu cuenta está pendiente de aprobación. Por favor, espera a que un docente la apruebe.'
      });
    }


    // Verificar contraseña
    const validPassword = await bcrypt.compare(contrasena, user.contrasena);
    if (!validPassword) {
      return res.status(400).json({ message: 'Credenciales inválidas' });
    }

    // Generar token
    const token = jwt.sign(
      {
        usuario: user.usuario,
        id_empresa: user.id_empresa,
        tipo_persona: user.tipo_persona,
        tipo_usuario: user.tipo_usuario
      },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    res.json({
      token,
      user: {
        usuario: user.usuario,
        id_empresa: user.id_empresa,
        tipo_persona: user.tipo_persona,
        tipo_usuario: user.tipo_usuario,
        estado_aprobacion: user.estado_aprobacion
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error en el servidor' });
  }
});

// Aprobar o rechazar estudiantes (solo docentes)
router.post('/aprobar-estudiante', auth, async (req, res) => {
  try {
    const { usuario, estado_aprobacion } = req.body;

    // Verificar que el usuario autenticado es docente
    const docenteResult = await db.query(
      'SELECT * FROM tbl_registro WHERE usuario = $1 AND tipo_usuario = $2',
      [req.user.usuario, 'docente']
    );

    if (docenteResult.rows.length === 0) {
      return res.status(403).json({ message: 'Solo los docentes pueden aprobar estudiantes' });
    }

    if (estado_aprobacion === 'rechazado') {
      // Si el estudiante es rechazado, eliminarlo de la base de datos
      const deleteResult = await db.query(
        'DELETE FROM tbl_registro WHERE usuario = $1 AND tipo_usuario = $2 RETURNING *',
        [usuario, 'estudiante']
      );

      if (deleteResult.rows.length === 0) {
        return res.status(404).json({ message: 'Estudiante no encontrado' });
      }

      return res.json({
        message: 'Estudiante rechazado y eliminado exitosamente',
        estudiante: deleteResult.rows[0]
      });
    } else {
      // Si el estudiante es aprobado, actualizar su estado
      const result = await db.query(
        'UPDATE tbl_registro SET estado_aprobacion = $1 WHERE usuario = $2 AND tipo_usuario = $3 RETURNING *',
        [estado_aprobacion, usuario, 'estudiante']
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ message: 'Estudiante no encontrado' });
      }

      res.json({
        message: 'Estudiante aprobado exitosamente',
        estudiante: result.rows[0]
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error en el servidor' });
  }
});

// Obtener estudiantes pendientes (solo docentes)
router.get('/estudiantes-pendientes', auth, async (req, res) => {
  try {
    // Verificar que el usuario autenticado es docente
    const docenteResult = await db.query(
      'SELECT * FROM tbl_registro WHERE usuario = $1 AND tipo_usuario = $2',
      [req.user.usuario, 'docente']
    );

    if (docenteResult.rows.length === 0) {
      return res.status(403).json({ message: 'Solo los docentes pueden ver estudiantes pendientes' });
    }

    // Obtener estudiantes pendientes
    const result = await db.query(
      'SELECT usuario, tipo_persona, fecha_registro FROM tbl_registro WHERE tipo_usuario = $1 AND estado_aprobacion = $2',
      ['estudiante', 'pendiente']
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error en el servidor' });
  }
});

module.exports = router;
