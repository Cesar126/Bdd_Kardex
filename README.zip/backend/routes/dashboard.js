const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

router.get('/stats', auth, async (req, res) => {
  try {
    // Obtener total de empresas y empresas activas
    const empresasResult = await db.query(
      'SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE emp_estado = $1) as activas FROM empresa',
      ['activo']
    );

    // Obtener total de productos y productos disponibles
    const productosResult = await db.query(
      'SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE pro_estado = $1) as disponibles FROM productos',
      ['disponible']
    );

    // Enviar la respuesta con los datos obtenidos
    res.json({
      totalEmpresas: parseInt(empresasResult.rows[0].total, 10),
      empresasActivas: parseInt(empresasResult.rows[0].activas, 10),
      totalProductos: parseInt(productosResult.rows[0].total, 10),
      productosDisponibles: parseInt(productosResult.rows[0].disponibles, 10)
    });
  } catch (error) {
    console.error('Error al obtener estadísticas:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

module.exports = router;
