const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

// Obtener todas las empresas asociadas al usuario
router.get('/', auth, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT e.* FROM tbl_empresa e ' +
      'JOIN tbl_empresa_registro er ON e.id = er.id_empresa ' +
      'WHERE er.usuario = $1 ORDER BY e.id DESC',
      [req.user.usuario]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error al obtener empresas:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Obtener una empresa específica
router.get('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      'SELECT * FROM tbl_empresa e ' +
      'JOIN tbl_empresa_registro er ON e.id = er.id_empresa ' +
      'WHERE e.id = $1 AND er.usuario = $2',
      [id, req.user.usuario]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Empresa no encontrada' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error al obtener la empresa:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Crear una nueva empresa
router.post('/', auth, async (req, res) => {
  try {
    const { nombre, razon_social } = req.body;
    
    // Verificar si los datos necesarios fueron enviados
    if (!nombre || !razon_social) {
      return res.status(400).json({ message: 'El nombre y la razón social son requeridos' });
    }

    // Crear la empresa
    const result = await db.query(
      'INSERT INTO tbl_empresa (nombre, razon_social, estado) VALUES ($1, $2, $3) RETURNING *',
      [nombre, razon_social, 'activo'] // Asume un estado 'activo' por defecto
    );

    const empresa = result.rows[0];

    // Asociar la empresa con el usuario actual (el usuario que está haciendo el request)
    await db.query(
      'INSERT INTO tbl_empresa_registro (id_empresa, usuario) VALUES ($1, $2)',
      [empresa.id, req.user.usuario] // Asocia la empresa recién creada con el usuario autenticado
    );
    
    res.status(201).json(empresa);
  } catch (error) {
    console.error('Error al crear empresa:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Actualizar una empresa
router.put('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, razon_social, estado } = req.body;
    
    // Verificar si los datos necesarios fueron enviados
    if (!nombre || !razon_social || !estado) {
      return res.status(400).json({ message: 'El nombre, razón social y estado son requeridos' });
    }

    const result = await db.query(
      'UPDATE tbl_empresa SET nombre = $1, razon_social = $2, estado = $3 WHERE id = $4 RETURNING *',
      [nombre, razon_social, estado, id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Empresa no encontrada' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error al actualizar la empresa:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;

    // Verificar si la empresa está asociada al usuario
    const empresaUsuario = await db.query(
      'SELECT * FROM tbl_empresa_registro WHERE id_empresa = $1 AND usuario = $2',
      [id, req.user.usuario]
    );

    if (empresaUsuario.rows.length === 0) {
      return res.status(403).json({ message: 'No tienes permiso para eliminar esta empresa' });
    }

    // Verificar si la empresa tiene productos asociados
    const productos = await db.query(
      'SELECT COUNT(*) FROM tbl_producto WHERE id_empresa = $1',
      [id]
    );

    if (parseInt(productos.rows[0].count) > 0) {
      return res.status(400).json({ 
        message: 'No se puede eliminar la empresa porque tiene productos asociados' 
      });
    }

    // Eliminar primero la relación empresa-usuario
    await db.query(
      'DELETE FROM tbl_empresa_registro WHERE id_empresa = $1 AND usuario = $2',
      [id, req.user.usuario]
    );

    // Luego eliminar la empresa
    const result = await db.query(
      'DELETE FROM tbl_empresa WHERE id = $1 RETURNING *',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Empresa no encontrada' });
    }

    res.json({ message: 'Empresa eliminada exitosamente' });
  } catch (error) {
    console.error('Error al eliminar la empresa:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});


module.exports = router;
