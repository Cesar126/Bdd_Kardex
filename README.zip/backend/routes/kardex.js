const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

// Obtener todos los movimientos de kardex (opcional: filtrar por empresa o producto)
router.get('/', auth, async (req, res) => {
  try {
    const { emp_id, prod_id } = req.query;
    let query = 'SELECT k.*, e.nombre as empresa_nombre, p.nombre as producto_nombre, u.usuario as usuario_nombre FROM tbl_kardex k LEFT JOIN tbl_empresa e ON k.emp_id = e.id LEFT JOIN tbl_producto p ON k.prod_id = p.id LEFT JOIN tbl_registro u ON k.usu_id = u.usuario WHERE 1=1';
    const params = [];
    if (emp_id) {
      query += ' AND k.emp_id = $' + (params.length + 1);
      params.push(emp_id);
    }
    if (prod_id) {
      query += ' AND k.prod_id = $' + (params.length + 1);
      params.push(prod_id);
    }
    query += ' ORDER BY k.kar_fecha DESC, k.kar_id DESC';
    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Error al obtener movimientos de kardex:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Crear un nuevo movimiento de kardex
router.post('/', auth, async (req, res) => {
  try {
    let {
      kar_detalle, kar_entCantidad, kar_entValorUnitario, kar_entiValorTotal,
      kar_saldoCantidad, kar_saldoValorUnitario, kar_saldoValorTotal,
      kar_exisCantidad, kar_exisValorUnitario, kar_exisValorTotal,
      emp_id, prod_id, kar_estado
    } = req.body;
    const usu_id = req.user.usuario;
    // Convertir a número o 0 si viene vacío
    kar_entCantidad = parseInt(kar_entCantidad) || 0;
    kar_entValorUnitario = parseFloat(kar_entValorUnitario) || 0;
    kar_entiValorTotal = parseFloat(kar_entiValorTotal) || 0;
    kar_saldoCantidad = parseInt(kar_saldoCantidad) || 0;
    kar_saldoValorUnitario = parseFloat(kar_saldoValorUnitario) || 0;
    kar_saldoValorTotal = parseFloat(kar_saldoValorTotal) || 0;
    kar_exisCantidad = parseInt(kar_exisCantidad) || 0;
    kar_exisValorUnitario = parseFloat(kar_exisValorUnitario) || 0;
    kar_exisValorTotal = parseFloat(kar_exisValorTotal) || 0;
    const result = await db.query(
      `INSERT INTO tbl_kardex (
        kar_detalle, kar_entCantidad, kar_entValorUnitario, kar_entiValorTotal,
        kar_saldoCantidad, kar_saldoValorUnitario, kar_saldoValorTotal,
        kar_exisCantidad, kar_exisValorUnitario, kar_exisValorTotal,
        usu_id, emp_id, prod_id, kar_estado
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
      [kar_detalle, kar_entCantidad, kar_entValorUnitario, kar_entiValorTotal,
        kar_saldoCantidad, kar_saldoValorUnitario, kar_saldoValorTotal,
        kar_exisCantidad, kar_exisValorUnitario, kar_exisValorTotal,
        usu_id, emp_id, prod_id, kar_estado || 'activo']
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error al crear movimiento de kardex:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Obtener movimientos de kardex por producto
router.get('/producto/:prod_id', auth, async (req, res) => {
  try {
    const { prod_id } = req.params;
    const result = await db.query(
      'SELECT * FROM tbl_kardex WHERE prod_id = $1 ORDER BY kar_fecha DESC, kar_id DESC',
      [prod_id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error al obtener movimientos de kardex por producto:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Obtener movimientos de kardex por empresa
router.get('/empresa/:emp_id', auth, async (req, res) => {
  try {
    const { emp_id } = req.params;
    const result = await db.query(
      'SELECT * FROM tbl_kardex WHERE emp_id = $1 ORDER BY kar_fecha DESC, kar_id DESC',
      [emp_id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error al obtener movimientos de kardex por empresa:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

module.exports = router; 