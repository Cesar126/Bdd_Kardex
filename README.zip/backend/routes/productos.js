const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

// Obtener todos los productos del usuario
router.get('/', auth, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT p.*, e.nombre as empresa_nombre 
      FROM tbl_producto p 
      LEFT JOIN tbl_empresa e ON p.id_empresa = e.id 
      JOIN tbl_empresa_registro er ON e.id = er.id_empresa
      WHERE er.usuario = $1
      ORDER BY p.id DESC
    `, [req.user.usuario]);
    res.json(result.rows);
  } catch (error) {
    console.error('Error al obtener productos:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Obtener productos por empresa (verificando que pertenezca al usuario)
router.get('/empresa/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(`
      SELECT p.* 
      FROM tbl_producto p
      JOIN tbl_empresa_registro er ON p.id_empresa = er.id_empresa
      WHERE er.id_empresa = $1 AND er.usuario = $2
      ORDER BY p.id DESC
    `, [id, req.user.usuario]);
    res.json(result.rows);
  } catch (error) {
    console.error('Error al obtener productos por empresa:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Obtener un producto específico (verificando que pertenezca al usuario)
router.get('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(`
      SELECT p.*, e.nombre as empresa_nombre 
      FROM tbl_producto p 
      LEFT JOIN tbl_empresa e ON p.id_empresa = e.id 
      JOIN tbl_empresa_registro er ON e.id = er.id_empresa
      WHERE p.id = $1 AND er.usuario = $2
    `, [id, req.user.usuario]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Producto no encontrado' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error al obtener el producto:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Crear un nuevo producto (verificando que la empresa pertenezca al usuario)
router.post('/', auth, async (req, res) => {
  try {
    const { nombre, descripcion, id_empresa } = req.body;
    
    // Validar los datos recibidos
    if (!nombre || !descripcion || !id_empresa) {
      return res.status(400).json({ message: 'Faltan datos requeridos (nombre, descripción, id_empresa)' });
    }

    // Verificar que la empresa pertenece al usuario
    const empresaCheck = await db.query(
      'SELECT * FROM tbl_empresa_registro WHERE id_empresa = $1 AND usuario = $2',
      [id_empresa, req.user.usuario]
    );

    if (empresaCheck.rows.length === 0) {
      return res.status(403).json({ message: 'No tienes permiso para crear productos en esta empresa' });
    }

    const result = await db.query(
      'INSERT INTO tbl_producto (nombre, descripcion, id_empresa) VALUES ($1, $2, $3) RETURNING *',
      [nombre, descripcion, id_empresa]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error al crear el producto:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Actualizar un producto
router.put('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, descripcion, estado, stock_actual } = req.body;

    // Validar los datos recibidos
    if (!nombre || !descripcion || !estado) {
      return res.status(400).json({ message: 'Faltan datos requeridos (nombre, descripción, estado)' });
    }

    let query = 'UPDATE tbl_producto SET nombre = $1, descripcion = $2, estado = $3';
    let params = [nombre, descripcion, estado];
    if (typeof stock_actual !== 'undefined') {
      query += ', stock_actual = $4';
      params.push(stock_actual);
      query += ' WHERE id = $5 RETURNING *';
      params.push(id);
    } else {
      query += ' WHERE id = $4 RETURNING *';
      params.push(id);
    }

    const result = await db.query(query, params);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Producto no encontrado' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error al actualizar el producto:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

// Eliminar un producto
router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar si el producto tiene movimientos en kardex
    const kardex = await db.query(
      'SELECT COUNT(*) FROM tbl_kardex WHERE id_producto = $1',
      [id]
    );
    
    if (kardex.rows[0].count > 0) {
      return res.status(400).json({ 
        message: 'No se puede eliminar el producto porque tiene movimientos en kardex' 
      });
    }
    
    const result = await db.query('DELETE FROM tbl_producto WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Producto no encontrado' });
    }
    
    res.json({ message: 'Producto eliminado exitosamente' });
  } catch (error) {
    console.error('Error al eliminar el producto:', error.message);
    res.status(500).json({ message: 'Error en el servidor', error: error.message });
  }
});

module.exports = router;
