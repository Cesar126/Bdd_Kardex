import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import Empresas from './components/Empresas';
import Productos from './components/Productos';
import AprobarEstudiantes from './components/AprobarEstudiantes';
import Navbar from './components/Navbar';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import Kardex from './components/Kardex';
import './App.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Navbar />
          <div className="container mt-4">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/dashboard" element={
                <PrivateRoute>
                  <Dashboard />
                </PrivateRoute>
              } />
              <Route path="/empresas" element={
                <PrivateRoute>
                  <Empresas />
                </PrivateRoute>
              } />
              <Route path="/productos" element={
                <PrivateRoute>
                  <Productos />
                </PrivateRoute>
              } />
              <Route path="/estudiantes-pendientes" element={
                <PrivateRoute requiredRole="docente">
                  <AprobarEstudiantes />
                </PrivateRoute>
              } />
              <Route path="/kardex" element={
                <PrivateRoute>
                  <Kardex />
                </PrivateRoute>
              } />
              <Route path="/" element={
                <PrivateRoute>
                  <Navigate to="/dashboard" replace />
                </PrivateRoute>
              } />
            </Routes>
          </div>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
