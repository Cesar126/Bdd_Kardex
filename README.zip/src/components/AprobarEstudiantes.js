import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';

function AprobarEstudiantes() {
  const { user } = useAuth();
  const [estudiantes, setEstudiantes] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const fetchEstudiantesPendientes = useCallback(async (retries = 3) => {
    try {
      const response = await fetch('http://localhost:3001/api/auth/estudiantes-pendientes', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setEstudiantes(data);
      } else {
        setError(data.message);
      }
    } catch (error) {
      if (retries > 0) {
        fetchEstudiantesPendientes(retries - 1);  // Retry
      } else {
        setError('Error al cargar estudiantes pendientes');
      }
    }
  }, [user?.token]);

  useEffect(() => {
    if (user?.tipo_usuario === 'docente') {
      fetchEstudiantesPendientes();
    }
  }, [user?.tipo_usuario, fetchEstudiantesPendientes]);

  const handleAprobar = async (usuario, estado) => {
    try {
      const response = await fetch('http://localhost:3001/api/auth/aprobar-estudiante', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`
        },
        body: JSON.stringify({ usuario, estado_aprobacion: estado })
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess(data.message);
        if (estado === 'rechazado') {
          setEstudiantes(estudiantes.filter(est => est.usuario !== usuario));
        } else {
          fetchEstudiantesPendientes();
        }
        setTimeout(() => setSuccess(''), 2000);
      } else {
        setError(data.message);
        setTimeout(() => setError(''), 2000);
      }
    } catch (err) {
      setError('Error al procesar la solicitud');
      setTimeout(() => setError(''), 2000);
    }
  };

  if (user?.tipo_usuario !== 'docente') {
    return (
      <div className="alert alert-danger">
        No tienes permiso para acceder a esta página
      </div>
    );
  }

  return (
    <div>
      <h2 className="mb-4">Estudiantes Pendientes</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}
      
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Lista de Estudiantes Pendientes</h5>
        </div>
        <div className="card-body">
          {estudiantes.length > 0 ? (
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Usuario</th>
                    <th>Tipo de Persona</th>
                    <th>Fecha de Registro</th>
                    <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {estudiantes.map((estudiante) => (
                    <tr key={estudiante.usuario}>
                      <td>{estudiante.usuario}</td>
                      <td>{estudiante.tipo_persona}</td>
                      <td>{new Date(estudiante.fecha_registro).toLocaleDateString()}</td>
                      <td>
                        <button
                          className="btn btn-success btn-sm me-2"
                          onClick={() => handleAprobar(estudiante.usuario, 'aprobado')}
                        >
                          <i className="bi bi-check-circle me-1"></i>
                          Aprobar
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => {
                            if (window.confirm('¿Estás seguro de rechazar a este estudiante? Esta acción eliminará al estudiante del sistema.')) {
                              handleAprobar(estudiante.usuario, 'rechazado');
                            }
                          }}
                        >
                          <i className="bi bi-x-circle me-1"></i>
                          Rechazar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-muted">No hay estudiantes pendientes de aprobación</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default AprobarEstudiantes; 