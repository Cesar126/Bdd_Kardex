import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalEmpresas: 0,
    totalProductos: 0,
    empresasActivas: 0,
    productosDisponibles: 0
  });
  const [ultimasEmpresas, setUltimasEmpresas] = useState([]);
  const [ultimosProductos, setUltimosProductos] = useState([]);

  useEffect(() => {
    fetchStats();
    fetchUltimasEmpresas();
    fetchUltimosProductos();
  }, []);

  const fetchStats = async () => {
    try {
      // Obtener total de empresas
      const empresasResponse = await fetch('http://localhost:3001/api/empresas', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const empresasData = await empresasResponse.json();
      
      // Obtener total de productos
      const productosResponse = await fetch('http://localhost:3001/api/productos', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const productosData = await productosResponse.json();

      if (empresasResponse.ok && productosResponse.ok) {
        setStats({
          totalEmpresas: empresasData.length,
          totalProductos: productosData.length,
          empresasActivas: empresasData.filter(emp => emp.estado === 'activo').length,
          productosDisponibles: productosData.filter(prod => prod.estado === 'disponible').length
        });
      }
    } catch (error) {
      console.error('Error al cargar estadísticas:', error);
    }
  };

  const fetchUltimasEmpresas = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/empresas', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setUltimasEmpresas(data.slice(0, 5)); // Obtener las últimas 5 empresas
      }
    } catch (error) {
      console.error('Error al cargar últimas empresas:', error);
    }
  };

  const fetchUltimosProductos = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/productos', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setUltimosProductos(data.slice(0, 5)); // Obtener los últimos 5 productos
      }
    } catch (error) {
      console.error('Error al cargar últimos productos:', error);
    }
  };

  return (
    <div>
      <h2 className="mb-4">Dashboard</h2>
      <div className="row">
        <div className="col-md-3 mb-4">
          <div className="card bg-primary text-white">
            <div className="card-body">
              <h5 className="card-title">Total Empresas</h5>
              <p className="card-text display-4">{stats.totalEmpresas}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-4">
          <div className="card bg-success text-white">
            <div className="card-body">
              <h5 className="card-title">Empresas Activas</h5>
              <p className="card-text display-4">{stats.empresasActivas}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-4">
          <div className="card bg-info text-white">
            <div className="card-body">
              <h5 className="card-title">Total Productos</h5>
              <p className="card-text display-4">{stats.totalProductos}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-4">
          <div className="card bg-warning text-white">
            <div className="card-body">
              <h5 className="card-title">Productos Disponibles</h5>
              <p className="card-text display-4">{stats.productosDisponibles}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">Últimas Empresas Registradas</h5>
            </div>
            <div className="card-body">
              {ultimasEmpresas.length > 0 ? (
                <div className="list-group">
                  {ultimasEmpresas.map((empresa) => (
                    <div key={empresa.id} className="list-group-item">
                      <h6 className="mb-1">{empresa.nombre}</h6>
                      <p className="mb-1 text-muted">{empresa.razon_social}</p>
                      <small className={`text-${empresa.estado === 'activo' ? 'success' : 'danger'}`}>
                        {empresa.estado}
                      </small>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted">No hay empresas registradas</p>
              )}
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">Últimos Productos Agregados</h5>
            </div>
            <div className="card-body">
              {ultimosProductos.length > 0 ? (
                <div className="list-group">
                  {ultimosProductos.map((producto) => (
                    <div key={producto.id} className="list-group-item">
                      <h6 className="mb-1">{producto.nombre}</h6>
                      <p className="mb-1 text-muted">{producto.empresa_nombre}</p>
                      <small className={`text-${producto.estado === 'disponible' ? 'success' : 'danger'}`}>
                        {producto.estado}
                      </small>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted">No hay productos agregados</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard; 