import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

function Empresas() {
  const { user } = useAuth();
  const [empresas, setEmpresas] = useState([]);
  const [formData, setFormData] = useState({
    nombre: '',
    razon_social: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchEmpresas();
  }, []);

  const fetchEmpresas = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/empresas', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setEmpresas(data);
      }
    } catch (error) {
      console.error('Error al cargar empresas:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      const response = await fetch('http://localhost:3001/api/empresas', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`
        },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess('Empresa creada exitosamente');
        setFormData({
          nombre: '',
          razon_social: ''
        });
        fetchEmpresas();
        setTimeout(() => setSuccess(''), 2000);
      } else {
        setError(data.message || 'Error al crear la empresa');
        setTimeout(() => setError(''), 2000);
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
      setTimeout(() => setError(''), 2000);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Está seguro de eliminar esta empresa?')) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:3001/api/empresas/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess('Empresa eliminada exitosamente');
        fetchEmpresas();
        setTimeout(() => setSuccess(''), 2000);
      } else {
        setError(data.message || 'Error al eliminar la empresa');
        setTimeout(() => setError(''), 2000);
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
      setTimeout(() => setError(''), 2000);
    }
  };

  const handleStatusChange = async (id, currentStatus) => {
    const newStatus = currentStatus === 'activo' ? 'inactivo' : 'activo';
    
    try {
      const response = await fetch(`http://localhost:3001/api/empresas/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`
        },
        body: JSON.stringify({
          estado: newStatus,
          nombre: empresas.find(emp => emp.id === id).nombre,
          razon_social: empresas.find(emp => emp.id === id).razon_social
        })
      });

      if (response.ok) {
        setSuccess(`Estado de la empresa actualizado a ${newStatus}`);
        fetchEmpresas();
        setTimeout(() => setSuccess(''), 2000);
      } else {
        const data = await response.json();
        setError(data.message || 'Error al actualizar el estado');
        setTimeout(() => setError(''), 2000);
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
      setTimeout(() => setError(''), 2000);
    }
  };

  return (
    <div>
      <h2 className="mb-4">Gestión de Empresas</h2>
      <div className="row">
        <div className="col-md-4">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">Nueva Empresa</h5>
            </div>
            <div className="card-body">
              {error && <div className="alert alert-danger">{error}</div>}
              {success && <div className="alert alert-success">{success}</div>}
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label htmlFor="nombre" className="form-label">Nombre</label>
                  <input
                    type="text"
                    className="form-control"
                    id="nombre"
                    name="nombre"
                    value={formData.nombre}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="razon_social" className="form-label">Razón Social</label>
                  <input
                    type="text"
                    className="form-control"
                    id="razon_social"
                    name="razon_social"
                    value={formData.razon_social}
                    onChange={handleChange}
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  Crear Empresa
                </button>
              </form>
            </div>
          </div>
        </div>
        <div className="col-md-8">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">Lista de Empresas</h5>
            </div>
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Nombre</th>
                      <th>Razón Social</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {empresas.map((empresa) => (
                      <tr key={empresa.id}>
                        <td>{empresa.id}</td>
                        <td>{empresa.nombre}</td>
                        <td>{empresa.razon_social}</td>
                        <td>
                          <span className={`badge bg-${empresa.estado === 'activo' ? 'success' : 'danger'}`}>
                            {empresa.estado}
                          </span>
                        </td>
                        <td>
                          <button 
                            className={`btn btn-sm ${empresa.estado === 'activo' ? 'btn-success' : 'btn-danger'} me-2`}
                            onClick={() => handleStatusChange(empresa.id, empresa.estado)}
                            title={empresa.estado === 'activo' ? 'Desactivar' : 'Activar'}
                          >
                            <i className={`bi bi-toggle-${empresa.estado === 'activo' ? 'on' : 'off'}`}></i>
                          </button>
                          <button 
                            className="btn btn-sm btn-danger"
                            onClick={() => handleDelete(empresa.id)}
                            title="Eliminar"
                          >
                            <i className="bi bi-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Empresas; 