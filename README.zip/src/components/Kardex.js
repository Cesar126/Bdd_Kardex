import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';

function Kardex() {
  const { user } = useAuth();
  const [movimientos, setMovimientos] = useState([]);
  const [productos, setProductos] = useState([]);
  const [productoFiltro, setProductoFiltro] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProductos();
  }, []);

  useEffect(() => {
    fetchMovimientos();
  }, [productoFiltro]);

  const fetchMovimientos = async () => {
    try {
      let url = 'http://localhost:3001/api/kardex';
      if (productoFiltro) {
        url += `?prod_id=${productoFiltro}`;
      }
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setMovimientos(data);
      }
    } catch (error) {
      setError('Error al cargar movimientos de kardex');
    }
  };

  const fetchProductos = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/productos', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setProductos(data);
      }
    } catch (error) {
      setError('Error al cargar productos');
    }
  };

  return (
    <div>
      <h2 className="mb-4">Kardex</h2>
      <div className="mb-3">
        <label className="form-label">Filtrar por producto:</label>
        <select className="form-select" value={productoFiltro} onChange={e => setProductoFiltro(e.target.value)}>
          <option value="">Todos los productos</option>
          {productos.map(prod => (
            <option key={prod.id} value={prod.id}>{prod.nombre}</option>
          ))}
        </select>
      </div>
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Movimientos de Kardex</h5>
        </div>
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Detalle</th>
                  <th>Empresa</th>
                  <th>Producto</th>
                  <th>Cant. Entrada</th>
                  <th>Valor Unitario</th>
                  <th>Valor Total</th>
                  <th>Saldo Cantidad</th>
                  <th>Existencia</th>
                  <th>Usuario</th>
                </tr>
              </thead>
              <tbody>
                {movimientos.map(mov => (
                  <tr key={mov.kar_id}>
                    <td>{new Date(mov.kar_fecha).toLocaleString()}</td>
                    <td>{mov.kar_detalle}</td>
                    <td>{mov.empresa_nombre}</td>
                    <td>{mov.producto_nombre}</td>
                    <td>{mov.kar_entCantidad ?? 0}</td>
                    <td>{mov.kar_entValorUnitario ?? 0}</td>
                    <td>{mov.kar_entiValorTotal ?? 0}</td>
                    <td>{mov.kar_saldoCantidad ?? 0}</td>
                    <td>{mov.kar_exisCantidad ?? 0}</td>
                    <td>{mov.usuario_nombre}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Kardex; 