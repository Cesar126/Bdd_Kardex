import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Navbar() {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  console.log('Usuario actual:', user); // Para depuración

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center" to={isAuthenticated ? "/dashboard" : "/"}>
          <i className="bi bi-building-gear me-2"></i>
          <span>Sistema Empresarial</span>
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          {isAuthenticated && (
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link d-flex align-items-center" to="/dashboard">
                  <i className="bi bi-speedometer2 me-1"></i>
                  Dashboard
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link d-flex align-items-center" to="/empresas">
                  <i className="bi bi-building me-1"></i>
                  Empresas
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link d-flex align-items-center" to="/productos">
                  <i className="bi bi-box-seam me-1"></i>
                  Productos
                </Link>
              </li>
              {user && user.tipo_usuario === 'docente' && (
                <li className="nav-item">
                  <Link className="nav-link d-flex align-items-center" to="/estudiantes-pendientes">
                    <i className="bi bi-person-check me-1"></i>
                    Estudiantes Pendientes
                  </Link>
                </li>
              )}
              <li className="nav-item">
                <Link className="nav-link d-flex align-items-center" to="/kardex">
                  <i className="bi bi-journal-text me-1"></i>
                  Kardex
                </Link>
              </li>
            </ul>
          )}
          <ul className="navbar-nav ms-auto">
            {isAuthenticated ? (
              <>
                <li className="nav-item">
                  <span className="nav-link d-flex align-items-center">
                    <i className="bi bi-person-circle me-1"></i>
                    {user?.usuario} ({user?.tipo_usuario})
                  </span>
                </li>
                <li className="nav-item">
                  <button
                    className="btn btn-link nav-link d-flex align-items-center"
                    onClick={handleLogout}
                  >
                    <i className="bi bi-box-arrow-right me-1"></i>
                    Cerrar Sesión
                  </button>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item">
                  <Link className="nav-link d-flex align-items-center" to="/login">
                    <i className="bi bi-box-arrow-in-right me-1"></i>
                    Iniciar Sesión
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link d-flex align-items-center" to="/register">
                    <i className="bi bi-person-plus me-1"></i>
                    Registrarse
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
