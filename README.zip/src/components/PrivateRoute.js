import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function PrivateRoute({ children, requiredRole }) {
  const { isAuthenticated, user } = useAuth();

  // Si no está autenticado, redirigir al login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Si se requiere un tipo de usuario específico y no lo tiene, redirigir a otra página
  if (requiredRole && user?.tipo_usuario !== requiredRole) {
    return <Navigate to="/dashboard" replace />;  // Redirigir a dashboard si no es 'docente'
  }

  return children;
}

export default PrivateRoute;
