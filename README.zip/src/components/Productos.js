import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

function Productos() {
  const { user } = useAuth();
  const [productos, setProductos] = useState([]);
  const [empresas, setEmpresas] = useState([]);
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    id_empresa: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [movimientoProducto, setMovimientoProducto] = useState(null);
  const [movForm, setMovForm] = useState({
    tipo: 'entrada',
    cantidad: '',
    valor_unitario: '',
    detalle: ''
  });

  useEffect(() => {
    fetchProductos();
    fetchEmpresas();
  }, []);

  const fetchProductos = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/productos', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setProductos(data);
      }
    } catch (error) {
      console.error('Error al cargar productos:', error);
    }
  };

  const fetchEmpresas = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/empresas', {
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setEmpresas(data);
      }
    } catch (error) {
      console.error('Error al cargar empresas:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      const response = await fetch('http://localhost:3001/api/productos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`
        },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess('Producto creado exitosamente');
        setFormData({
          nombre: '',
          descripcion: '',
          id_empresa: ''
        });
        fetchProductos();
        setTimeout(() => setSuccess(''), 2000);
      } else {
        setError(data.message || 'Error al crear el producto');
        setTimeout(() => setError(''), 2000);
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
      setTimeout(() => setError(''), 2000);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Está seguro de eliminar este producto?')) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:3001/api/productos/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${user?.token}`
        }
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess('Producto eliminado exitosamente');
        fetchProductos();
        setTimeout(() => setSuccess(''), 2000);
      } else {
        setError(data.message || 'Error al eliminar el producto');
        setTimeout(() => setError(''), 2000);
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
      setTimeout(() => setError(''), 2000);
    }
  };

  const handleStatusChange = async (id, currentStatus) => {
    const newStatus = currentStatus === 'disponible' ? 'no disponible' : 'disponible';
    const producto = productos.find(prod => prod.id === id);
    
    try {
      const response = await fetch(`http://localhost:3001/api/productos/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`
        },
        body: JSON.stringify({
          nombre: producto.nombre,
          descripcion: producto.descripcion,
          id_empresa: producto.id_empresa,
          estado: newStatus
        })
      });

      if (response.ok) {
        setSuccess(`Estado del producto actualizado a ${newStatus}`);
        fetchProductos();
        setTimeout(() => setSuccess(''), 2000);
      } else {
        const data = await response.json();
        setError(data.message || 'Error al actualizar el estado');
        setTimeout(() => setError(''), 2000);
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
      setTimeout(() => setError(''), 2000);
    }
  };

  const abrirModalMovimiento = (producto) => {
    setMovimientoProducto(producto);
    setMovForm({ tipo: 'entrada', cantidad: '', valor_unitario: '', detalle: '' });
    setShowModal(true);
  };

  const cerrarModalMovimiento = () => {
    setShowModal(false);
    setMovimientoProducto(null);
  };

  const handleMovChange = (e) => {
    setMovForm({ ...movForm, [e.target.name]: e.target.value });
  };

  const handleMovSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!movimientoProducto) return;
    try {
      // Calcular nuevos valores de stock y totales
      const cantidad = parseInt(movForm.cantidad) || 0;
      const valor_unitario = parseFloat(movForm.valor_unitario) || 0;
      const esEntrada = movForm.tipo === 'entrada';
      const stockAnterior = movimientoProducto.stock_actual || 0;
      const stockNuevo = esEntrada ? stockAnterior + cantidad : stockAnterior - cantidad;
      const valorTotal = cantidad * valor_unitario;

      // Actualizar stock del producto
      await fetch(`http://localhost:3001/api/productos/${movimientoProducto.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`
        },
        body: JSON.stringify({
          nombre: movimientoProducto.nombre,
          descripcion: movimientoProducto.descripcion,
          id_empresa: movimientoProducto.id_empresa,
          estado: movimientoProducto.estado,
          stock_actual: stockNuevo
        })
      });

      // Registrar movimiento en kardex
      await fetch('http://localhost:3001/api/kardex', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`
        },
        body: JSON.stringify({
          kar_detalle: movForm.detalle || (esEntrada ? 'Entrada de inventario' : 'Salida de inventario'),
          kar_entCantidad: cantidad,
          kar_entValorUnitario: valor_unitario,
          kar_entiValorTotal: valorTotal,
          kar_saldoCantidad: stockNuevo,
          kar_saldoValorUnitario: valor_unitario,
          kar_saldoValorTotal: stockNuevo * valor_unitario,
          kar_exisCantidad: stockNuevo,
          kar_exisValorUnitario: valor_unitario,
          kar_exisValorTotal: stockNuevo * valor_unitario,
          emp_id: movimientoProducto.id_empresa,
          prod_id: movimientoProducto.id,
          kar_estado: 'activo'
        })
      });

      setSuccess('Movimiento registrado y stock actualizado');
      fetchProductos();
      cerrarModalMovimiento();
      setTimeout(() => setSuccess(''), 2000);
    } catch (err) {
      setError('Error al registrar el movimiento');
      setTimeout(() => setError(''), 2000);
    }
  };

  // Modal de movimiento de inventario
  const ModalMovimiento = () => showModal && movimientoProducto && (
    <div className="modal show d-block" tabIndex="-1" style={{ background: 'rgba(0,0,0,0.3)' }}>
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Registrar Movimiento - {movimientoProducto.nombre}</h5>
            <button type="button" className="btn-close" onClick={cerrarModalMovimiento}></button>
          </div>
          <form onSubmit={handleMovSubmit}>
            <div className="modal-body">
              <div className="mb-3">
                <label className="form-label">Tipo de Movimiento</label>
                <select className="form-select" name="tipo" value={movForm.tipo} onChange={handleMovChange} required>
                  <option value="entrada">Entrada</option>
                  <option value="salida">Salida</option>
                </select>
              </div>
              <div className="mb-3">
                <label className="form-label">Cantidad</label>
                <input type="number" className="form-control" name="cantidad" value={movForm.cantidad} onChange={handleMovChange} required min="1" />
              </div>
              <div className="mb-3">
                <label className="form-label">Valor Unitario</label>
                <input type="number" step="0.01" className="form-control" name="valor_unitario" value={movForm.valor_unitario} onChange={handleMovChange} required min="0" />
              </div>
              <div className="mb-3">
                <label className="form-label">Detalle</label>
                <input type="text" className="form-control" name="detalle" value={movForm.detalle} onChange={handleMovChange} />
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={cerrarModalMovimiento}>Cancelar</button>
              <button type="submit" className="btn btn-primary">Registrar</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <h2 className="mb-4">Gestión de Productos</h2>
      <div className="row">
        <div className="col-md-4">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">Nuevo Producto</h5>
            </div>
            <div className="card-body">
              {error && <div className="alert alert-danger">{error}</div>}
              {success && <div className="alert alert-success">{success}</div>}
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label htmlFor="nombre" className="form-label">Nombre</label>
                  <input
                    type="text"
                    className="form-control"
                    id="nombre"
                    name="nombre"
                    value={formData.nombre}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="descripcion" className="form-label">Descripción</label>
                  <textarea
                    className="form-control"
                    id="descripcion"
                    name="descripcion"
                    value={formData.descripcion}
                    onChange={handleChange}
                    rows="3"
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="id_empresa" className="form-label">Empresa</label>
                  <select
                    className="form-select"
                    id="id_empresa"
                    name="id_empresa"
                    value={formData.id_empresa}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Seleccione una empresa</option>
                    {empresas.map((empresa) => (
                      <option key={empresa.id} value={empresa.id}>
                        {empresa.nombre}
                      </option>
                    ))}
                  </select>
                </div>
                <button type="submit" className="btn btn-primary">
                  Crear Producto
                </button>
              </form>
            </div>
          </div>
        </div>
        <div className="col-md-8">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">Lista de Productos</h5>
            </div>
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Nombre</th>
                      <th>Descripción</th>
                      <th>Empresa</th>
                      <th>Stock</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {productos.map((producto) => (
                      <tr key={producto.id}>
                        <td>{producto.id}</td>
                        <td>{producto.nombre}</td>
                        <td>{producto.descripcion}</td>
                        <td>{producto.empresa_nombre}</td>
                        <td>{producto.stock_actual ?? 0}</td>
                        <td>
                          <span className={`badge bg-${producto.estado === 'disponible' ? 'success' : 'danger'}`}>
                            {producto.estado}
                          </span>
                        </td>
                        <td>
                          <button 
                            className={`btn btn-sm ${producto.estado === 'disponible' ? 'btn-success' : 'btn-danger'} me-2`}
                            onClick={() => handleStatusChange(producto.id, producto.estado)}
                            title={producto.estado === 'disponible' ? 'Marcar como no disponible' : 'Marcar como disponible'}
                          >
                            <i className={`bi bi-toggle-${producto.estado === 'disponible' ? 'on' : 'off'}`}></i>
                          </button>
                          <button 
                            className="btn btn-sm btn-danger"
                            onClick={() => handleDelete(producto.id)}
                            title="Eliminar"
                          >
                            <i className="bi bi-trash"></i>
                          </button>
                          <button className="btn btn-sm btn-info me-2" onClick={() => abrirModalMovimiento(producto)} title="Movimiento de inventario">
                            <i className="bi bi-box-arrow-in-down"></i> Movimiento
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      {ModalMovimiento()}
    </div>
  );
}

export default Productos; 